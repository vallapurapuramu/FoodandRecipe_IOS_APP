//
//  searchResultResponse.swift
//  Food and Recipe
//
//  Created by student on 12/4/21.
//

import Foundation

struct SearchResultResponse: Codable {
    let offset: Int
    let number: Int
    let totalResults: Int
    let results: [SearchedRecipes]
}
